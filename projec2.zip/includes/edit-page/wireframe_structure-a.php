<div id="container-type-a">
    <div id="type-a-title">
        <h2><?php echo $page_title; ?></h2>
    </div>
    <div id="type-a-section1">
        <div id="type-a-img">
            <img src="./img/uploads/<?php echo $page_img1; ?>" alt="">
        </div>
        <div id="type-a-text1">
            <p>
            <?php echo $page_text1; ?>   
            </p>
        </div>
    </div>
    <div id="type-a-section2">
        <div id="type-a-text2">
            <p>
            <?php echo $page_text2; ?>    
            </p>
        </div>
        <div id="type-a-img">
        <img src="./img/uploads/<?php echo $page_img2; ?>" alt="">
        </div>
    </div>
</div>