<div id="container-type-b">
    <div id="type-b-title">
        <h2><?php echo $page_title; ?></h2>
    </div>
    <div id="type-b-section1">
        <div id="type-b-img">
        <img src="./img/uploads/<?php echo $page_img1; ?>" alt="">
        </div>
        <div id="type-b-text1">
            <p>
                <?php echo $page_text1; ?>
            </p>
        </div>
    </div>
    <div id="type-b-section2">
        <div id="type-b-text2">
            <p>
                <?php echo $page_text2; ?>
            </p>
        </div>
        <div id="type-b-img">
        <img src="./img/uploads/<?php echo $page_img2; ?>" alt="">
        </div>

    </div>
</div>