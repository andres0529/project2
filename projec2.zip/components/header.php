<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon "></span>
    </button>
    <div class="collapse navbar-collapse " id="navbarNavAltMarkup">
        <div class="navbar-nav w-25">
            <img src="./img/logo.png" alt="" width="325">
        </div>
        <div class="navbar-nav d-flex justify-content-around w-75">
            <a class="nav-item nav-link" href="./home.php">Home </a>
            <a class="nav-item nav-link" href="./manage_users.php">Manage Users</a>
            <a class="nav-item nav-link" href="./manage_pages.php">Manage Pages</a>
            <a class="nav-item nav-link" href="./includes/logout.inc.php">Log Out</a>
        </div>
    </div>
</nav>